package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Cart;
import com.example.demo.entity.Customer;
import com.example.demo.entity.VegetableDTO;
import com.example.demo.repository.CartRepository;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.repository.VegetableDTORepository;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	private CartRepository cartRepository;

//	@Autowired
//	private CustomerRepository customerRepository;
//
//	@Autowired
//	private VegetableDTORepository vegetableDTORepository;

//	
//	public Cart decreaseVegQuantntity(int vegId, int quantity, int customerId) {
//		Customer customer = customerRepository.findById(customerId).orElse(null);
//		if (customer == null) {
//			return null;
//		}
//		Cart cart = cartRepository.findByCustId(customerId);
//
//		VegetableDTO vegetableDTO = vegetableDTORepository.findById(vegId).orElse(null);
//		vegetableDTO.setQuantity(quantity);
//
//		return cart;
//	}
//
//	public Cart removeVegetable(int vegId, int customerId) {
//		Cart cart = cartRepository.findByCustId(customerId);
//		cart.getVegetables().remove(vegId);
//		return cart;
//	}
//
//	public Cart removeAllVegetable(int customerId) {
//		Cart cart = cartRepository.findByCustId(customerId);
//		cart.getVegetables().removeAll(cart.getVegetables());
//
//		return cart;
//	}
//
//	public List<VegetableDTO> viewAllItems(int customerId) {
//		Cart cart = cartRepository.findByCustId(customerId);
//		return cart.getVegetables();
//	}
//
}
