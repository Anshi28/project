package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.service.CartService;

@RestController
@CrossOragin(oragin = "http://localhost:4200/")
public class cartController 
{
	@Autowired
	private CartService CartService;
	
	@GetMapping("/cart/add")
	public void addTocart(@RequestBody vegetableDTO v, @RequestParam customerId c) 
	{
		CartService.addTocart(v, c);
	}
	@PutMapping("cart/add")
	public String addTocart(@RequestBody vegetableDTO v, customerId c) 
	{
		CartService.addTocart(v, c);
	}
	
}
