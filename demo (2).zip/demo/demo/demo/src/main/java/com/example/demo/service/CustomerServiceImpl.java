package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Customer;
import com.example.demo.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService  {

	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Customer addCustomer(Customer customer) {
		return customerRepository.save(customer);
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		return customerRepository.save(customer);
	}

	@Override
	public Customer removCustomer(Customer customer) {
		Customer customer2 = customerRepository.findById(customer.getCustomerId()).orElse(null);
		customerRepository.delete(customer2);
		return customer2;
	}

	@Override
	public Customer viewCustomer(Customer customer) {
		return customerRepository.findById(customer.getCustomerId()).orElse(null);
	}

	// doubt
//	public List<Customer> viewCustomer() {
//		
//	}

}
